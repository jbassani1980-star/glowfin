const ZAPI_INSTANCE = '3F1B998AAB26F1F1F6556E59E5E6857E';
const ZAPI_TOKEN = '88B19042482055F821473534';
const ZAPI_CLIENT_TOKEN = process.env.ZAPI_CLIENT_TOKEN;
const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;
const MEU_NUMERO = process.env.MEU_NUMERO;

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return { statusCode: 200, body: 'OK' };

  let body;
  try { body = JSON.parse(event.body); } catch(e) { return { statusCode: 200, body: 'OK' }; }

  console.log('Webhook:', JSON.stringify(body).substring(0, 300));

  // FILTRO 1: Ignora mensagens enviadas por mim (evita loop)
  if (body.fromMe === true) return { statusCode: 200, body: 'OK' };

  // FILTRO 2: Ignora se não tiver texto
  if (!body.text || !body.text.message) return { statusCode: 200, body: 'OK' };

  // FILTRO 3: Só processa mensagens do SEU número
  const telefone = body.phone;
  if (MEU_NUMERO) {
    const numLimpo = MEU_NUMERO.replace(/\D/g,'');
    const telLimpo = (telefone||'').replace(/\D/g,'');
    if (!telLimpo.includes(numLimpo) && !numLimpo.includes(telLimpo)) {
      console.log('Ignorado - não é o dono:', telefone);
      return { statusCode: 200, body: 'OK' };
    }
  }

  const mensagem = body.text.message;
  console.log('Processando:', mensagem);

  const prompt = `Você é um assistente financeiro. O usuário enviou via WhatsApp: "${mensagem}"

Responda APENAS com JSON:
{
  "tipo": "receita" ou "despesa",
  "valor": número sem R$,
  "descricao": "descrição curta",
  "categoria": uma de: venda, recebimento, outras_receitas, folha, aluguel, fornecedor, marketing, utilities, imposto, contabilidade, emprestimo, juros, outros,
  "valido": true ou false,
  "mensagem_resposta": "confirmação ou pedido de mais info"
}`;

  try {
    const aiResp = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-api-key': ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: 'claude-haiku-4-5-20251001', max_tokens: 500, messages: [{ role: 'user', content: prompt }] })
    });

    const aiData = await aiResp.json();
    const aiText = aiData.content[0].text;
    
    let lanc;
    try { lanc = JSON.parse(aiText.replace(/```json|```/g,'').trim()); }
    catch(e) { await enviar(telefone, '❌ Não entendi. Tente: "despesa aluguel 2500"'); return { statusCode: 200, body: 'OK' }; }

    if (!lanc.valido) {
      await enviar(telefone, lanc.mensagem_resposta || '❌ Não entendi. Tente: "despesa aluguel 2500"');
      return { statusCode: 200, body: 'OK' };
    }

    const hoje = new Date().toISOString().split('T')[0];
    const emoji = lanc.tipo === 'receita' ? '💚' : '🔴';
    const msg = `${emoji} *GlowFin — Lançamento registrado!*\n\n📝 ${lanc.descricao}\n💰 R$ ${Number(lanc.valor).toLocaleString('pt-BR',{minimumFractionDigits:2})}\n📊 ${lanc.tipo==='receita'?'Receita':'Despesa'}\n📅 ${hoje.split('-').reverse().join('/')}`;
    
    await enviar(telefone, msg);
    return { statusCode: 200, body: JSON.stringify({ success: true }) };

  } catch(e) {
    console.error('Erro:', e);
    return { statusCode: 200, body: 'OK' };
  }
};

async function enviar(telefone, mensagem) {
  try {
    await fetch(`https://api.z-api.io/instances/${ZAPI_INSTANCE}/token/${ZAPI_TOKEN}/send-text`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Client-Token': ZAPI_CLIENT_TOKEN },
      body: JSON.stringify({ phone: telefone, message: mensagem })
    });
  } catch(e) { console.error('Erro envio:', e); }
}
